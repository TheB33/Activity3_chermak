﻿using UnityEngine;
using System.Collections;

public class DRId : MonoBehaviour 
{

    public int id = -1;


}
