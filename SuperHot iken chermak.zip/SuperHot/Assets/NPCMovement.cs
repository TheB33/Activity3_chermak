﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NPCMovement : MonoBehaviour
{
    public float speed;
    public GameObject player;
    bool istrigger;
    public GameObject npc;
    public Rigidbody rb;
    // Use this for initialization
    void Start()
    {
        rb = this.GetComponent<Rigidbody>();

    }

    // Update is called once per frame
    void Update()
    {
        if (Mathf.Abs(transform.position.x-player.transform.position.x)<8&&Mathf.Abs(transform.position.z-player.transform.position.z)<8)
        {
            this.transform.LookAt(player.transform);
            float step = speed * Time.deltaTime;
            transform.position = Vector3.MoveTowards(transform.position, player.transform.position, step);
        }
    }
    
}
