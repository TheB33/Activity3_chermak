﻿using UnityEngine;
using System.Collections;

public class ShootableBox : MonoBehaviour
{
    public GameObject obj;
    //The box's current health point total
    public int currentHealth = 3;
    public bool ishit=false;
   
    
    private void Update()
    {
        if (ishit)
        {
            currentHealth -= 1;
            ishit = false;
            
        }
        if (currentHealth <= 0)
        {
            //if health has fallen below zero, deactivate it 
            Object.Destroy(obj);
        }
    }

}